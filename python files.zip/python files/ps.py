from PIL import Image, ImageOps
from PIL import ImageEnhance as IE #can use alias
from PIL import ImageDraw as ID
from PIL import ImageFont as IF

class PhotoStore():
    
    def __init__(self,raw_image):
        """
        Instantiate class and store raw image in a class variable.
        
        Input:
            raw_image: Raw image to be altered.
        """
        self.raw_image = raw_image
        
        
    def save_image(self,image,path):
        """
        Simple function to save edited image.

        Input:
            image: Image to be saved.
            path: Path to save image to.
        """
        print (path)
        return image.save(path)